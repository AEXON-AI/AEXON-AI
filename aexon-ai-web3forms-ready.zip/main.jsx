import { createRoot } from 'react-dom/client';
import App from './index.js';
createRoot(document.getElementById('root')).render(<App />);
